# api-projeto-site 🥇

Descrição: código de **API-projeto-site** para a Disciplina de **Pesquisa e Inovação** - 1º Semestre @ Bandtec - 2021/01

## :zap: Como usar? 

Vá até o diretório ```/API-projeto-site``` e siga o passo a passo presente em ```"COMO-USAR.txt"```.
