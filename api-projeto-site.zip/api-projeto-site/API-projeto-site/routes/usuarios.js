var express = require('express');
var router = express.Router();
var sequelize = require('../models').sequelize;
var Usuario = require('../models').Usuario;
var Personagem = require('../models').Personagem;
var Filme = require('../models').Filme;

let sessoes = [];

/* Recuperar usuário por login e senha */
//validação do login através de dados do BD

router.post('/autenticar', function(req, res, next) {
	console.log('Recuperando usuário por login e senha');

	var login = req.body.login; // depois de .body, use o nome (name) do campo em seu formulário de login
	//aqui em cima pego o valor do login lá do BD
	var senha = req.body.senha; // depois de .body, use o nome (name) do campo em seu formulário de login	
	//aqui em cima pego o valor da senha lá do BD
	
	let instrucaoSql = `select * from usuario where login='${login}' and senha='${senha}'`;//faço o select da senha e do login no bd , especifico que eu escrevi
	
	console.log(instrucaoSql);

	sequelize.query(instrucaoSql, {
		model: Usuario
	}).then(resultado => {
		console.log(`Encontrados: ${resultado.length}`);

		if (resultado.length == 1) {
			sessoes.push(resultado[0].dataValues.login);
			console.log('sessoes: ',sessoes);
			res.json(resultado[0]); //caso apenas 1 usuario seja localizado irá realizar o login

		} else if (resultado.length == 0) {
			res.status(403).send('Login e/ou senha inválido(s)');//se nenhum login inválido

		} else {
			res.status(403).send('Mais de um usuário com o mesmo login e senha!'); //se mais que um igual , erro
		}

	}).catch(erro => {
		console.error(erro);
		res.status(500).send(erro.message);
  	});
});





/* Cadastrar usuário */
router.post('/cadastrar', function(req, res, next) {
	console.log('Criando um usuário');
	
	Usuario.create({
		nome : req.body.nome,
		login : req.body.login,
		senha: req.body.senha // isso é o que preciso para criar um usuário/cadastrar
		//adiciono os campos do cadastro ex: no meu faltariam animacao e personagem
	}).then(resultado => {
		console.log(`Registro criado: ${resultado}`)
        res.send(resultado); //cadastro deu certo
    }).catch(erro => {
		console.error(erro);
		res.status(500).send(erro.message);
  	});
});


/*TESTE CADASTRO PERSONAGEM*/

router.post('/cadastrarPersonagem', function(req, res, next) {
	console.log('Criando um personagem');
	
	Personagem.create({
		nome : req.body.nome,
		data: req.body.data,
		descricao: req.body.descricao // isso é o que preciso para criar um usuário/cadastrar
		//adiciono os campos do cadastro ex: no meu faltariam animacao e personagem
	}).then(resultado => {
		console.log(`Registro criado: ${resultado}`)
        res.send(resultado); //cadastro deu certo
    }).catch(erro => {
		console.error(erro);
		res.status(500).send(erro.message);
  	});
});

/*FIM TESTE CADASTRO*/


/*TESTE CADASTRO PERSONAGEM*/

router.post('/cadastrarFilme', function(req, res, next) {
	console.log('Criando um filme');
	
	Filme.create({
		nome : req.body.nome,
		ano_lancamento: req.body.anoLancamento,
		 // isso é o que preciso para criar um usuário/cadastrar
		//adiciono os campos do cadastro ex: no meu faltariam animacao e personagem
	}).then(resultado => {
		console.log(`Registro criado: ${resultado}`)
        res.send(resultado); //cadastro deu certo
    }).catch(erro => {
		console.error(erro);
		res.status(500).send(erro.message);
  	});
});

/*FIM TESTE CADASTRO*/



/* Verificação de usuário */
//aqui vai verificar se o usuário já está logado ou não; acho que não se aplica por enquanto em meu e nosso site
router.get('/sessao/:login', function(req, res, next) {
	let login = req.params.login;
	console.log(`Verificando se o usuário ${login} tem sessão`);
	
	let tem_sessao = false;
	for (let u=0; u<sessoes.length; u++) {
		if (sessoes[u] == login) {
			tem_sessao = true;
			break;
		}
	}

	if (tem_sessao) {
		let mensagem = `Usuário ${login} possui sessão ativa!`;
		console.log(mensagem);
		res.send(mensagem);
	} else {
		res.sendStatus(403);
	}
	
});


/* Logoff de usuário */
//aqui o usuário irá sair do login 

router.get('/sair/:login', function(req, res, next) {
	let login = req.params.login;
	console.log(`Finalizando a sessão do usuário ${login}`);
	let nova_sessoes = []
	for (let u=0; u<sessoes.length; u++) {
		if (sessoes[u] != login) {
			nova_sessoes.push(sessoes[u]);
		}
	}
	sessoes = nova_sessoes;
	res.send(`Sessão do usuário ${login} finalizada com sucesso!`); //se der certo
});




/* Recuperar todos os usuários */
router.get('/', function(req, res, next) {
	console.log('Recuperando todos os usuários');
	Usuario.findAndCountAll().then(resultado => {
		console.log(`${resultado.count} registros`);

		res.json(resultado.rows);
	}).catch(erro => {
		console.error(erro);
		res.status(500).send(erro.message);
  	});
});

module.exports = router;
