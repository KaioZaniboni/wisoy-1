'use strict';

/* 
lista e explicação dos Datatypes:
https://codewithhugo.com/sequelize-data-types-a-practical-guide/
*/

module.exports = (sequelize, DataTypes) => {
    let Filme = sequelize.define('Filme',{
		id: {
			field: 'idFilme',
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},		
		nome: {
			field: 'nome',
			type: DataTypes.STRING,
			allowNull: false
		},
		ano_lancamento: {
			field: 'ano_lancamento',
			type: DataTypes.STRING,
			allowNull: false
		}
		
	}, 
	{
		tableName: 'filmes', 
		freezeTableName: true, 
		underscored: true,
		timestamps: false,
	});

    return Filme;
};

