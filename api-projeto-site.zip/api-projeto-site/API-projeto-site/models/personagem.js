'use strict';

/* 
lista e explicação dos Datatypes:
https://codewithhugo.com/sequelize-data-types-a-practical-guide/
*/

module.exports = (sequelize, DataTypes) => {
    let Personagem = sequelize.define('Personagem',{
		id: {
			field: 'idPersonagem',
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},		
		nome: {
			field: 'nome',
			type: DataTypes.STRING,
			allowNull: false
		},
		data: {
			field: 'data_nascimento',
			type: DataTypes.DATE,
			allowNull: false
		},
		descricao: {
			field: 'descricao',
			type: DataTypes.STRING,
			allowNull: false
		}
	}, 
	{
		tableName: 'Personagem', 
		freezeTableName: true, 
		underscored: true,
		timestamps: false,
	});

    return Personagem;
};

